<?php
require_once 'includes/config.php';

// Get filter parameters
$breed = $_GET['breed'] ?? '';
$gender = $_GET['gender'] ?? '';
$age = $_GET['age'] ?? '';

// Build the query
$query = "SELECT DISTINCT * FROM cats WHERE status = 'available'";
$params = [];

if ($breed) {
    $query .= " AND breed = ?";
    $params[] = $breed;
}
if ($gender) {
    $query .= " AND gender = ?";
    $params[] = $gender;
}
if ($age) {
    $query .= " AND age <= ?";
    $params[] = $age;
}

$query .= " ORDER BY name";

// Fetch filtered cats
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$cats = $stmt->fetchAll();

// Fetch unique breeds for filter
$breeds = $pdo->query("SELECT DISTINCT breed FROM cats WHERE status = 'available' ORDER BY breed")->fetchAll(PDO::FETCH_COLUMN);
?>

<?php include 'includes/header.php'; ?>

<!-- Hero Banner -->
<div class="py-5 text-center" style="background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);">
    <div class="container">
        <h1 class="display-4 fw-bold mb-2">Find Your New Best Friend</h1>
        <p class="lead mb-0">Browse our adorable cats waiting for a loving home!</p>
    </div>
</div>

<div class="container my-5">
    <!-- Filters -->
    <div class="card filter-card mb-4 shadow-sm border-0 rounded-4">
        <div class="card-body">
            <form method="GET" class="row g-3 align-items-end">
                <div class="col-md-4">
                    <label for="breed" class="form-label"><i class="fas fa-dna me-1"></i> Breed</label>
                    <select class="form-select" id="breed" name="breed">
                        <option value="">All Breeds</option>
                        <?php foreach ($breeds as $b): ?>
                            <option value="<?php echo htmlspecialchars($b); ?>" <?php echo $breed === $b ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($b); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="gender" class="form-label"><i class="fas fa-venus-mars me-1"></i> Gender</label>
                    <select class="form-select" id="gender" name="gender">
                        <option value="">All Genders</option>
                        <option value="Male" <?php echo $gender === 'Male' ? 'selected' : ''; ?>>Male</option>
                        <option value="Female" <?php echo $gender === 'Female' ? 'selected' : ''; ?>>Female</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label for="age" class="form-label"><i class="fas fa-birthday-cake me-1"></i> Maximum Age</label>
                    <select class="form-select" id="age" name="age">
                        <option value="">Any Age</option>
                        <option value="1" <?php echo $age === '1' ? 'selected' : ''; ?>>1 year or less</option>
                        <option value="2" <?php echo $age === '2' ? 'selected' : ''; ?>>2 years or less</option>
                        <option value="3" <?php echo $age === '3' ? 'selected' : ''; ?>>3 years or less</option>
                        <option value="5" <?php echo $age === '5' ? 'selected' : ''; ?>>5 years or less</option>
                    </select>
                </div>
                <div class="col-12 text-center mt-3">
                    <button type="submit" class="btn btn-primary px-4"><i class="fas fa-filter me-1"></i> Apply Filters</button>
                    <a href="adoption.php" class="btn btn-outline-secondary ms-2">Clear Filters</a>
                </div>
            </form>
        </div>
    </div>

    <?php if (empty($cats)): ?>
        <div class="alert alert-info text-center py-5 rounded-4 shadow-sm">
            <i class="fas fa-cat fa-2x mb-2"></i><br>
            <strong>No cats match your current filters.</strong><br>
            Please try different criteria or check back soon!
        </div>
    <?php else: ?>
        <div class="row row-cols-1 row-cols-md-2 row-cols-lg-3 g-4">
            <?php foreach ($cats as $cat): ?>
                <div class="col">
                    <div class="card h-100 cat-card border-0 shadow-lg rounded-4">
                        <div class="image-container position-relative">
                            <?php
                            $image_path = 'assets/uploads/' . $cat['image'];
                            $default_image = 'assets/images/default-cat.jpg';
                            ?>
                            <img src="<?php echo file_exists($image_path) ? $image_path : $default_image; ?>"
                                 class="card-img-top adopt-img"
                                 alt="<?php echo htmlspecialchars($cat['name']); ?>"
                                 onerror="this.src='<?php echo $default_image; ?>'">
                            <span class="badge bg-<?php echo $cat['gender'] === 'Male' ? 'primary' : 'danger'; ?> position-absolute top-0 start-0 m-2 px-3 py-2 fs-6">
                                <i class="fas fa-<?php echo $cat['gender'] === 'Male' ? 'mars' : 'venus'; ?> me-1"></i> <?php echo htmlspecialchars($cat['gender']); ?>
                            </span>
                            <span class="badge bg-success position-absolute top-0 end-0 m-2 px-3 py-2 fs-6">
                                <?php echo htmlspecialchars($cat['age']); ?> yrs
                            </span>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title fw-bold mb-2"><?php echo htmlspecialchars($cat['name']); ?></h5>
                            <p class="card-text mb-2">
                                <strong>Breed:</strong> <?php echo htmlspecialchars($cat['breed']); ?>
                            </p>
                            <p class="card-text small text-muted mb-3" style="min-height: 48px;">
                                <?php echo htmlspecialchars($cat['description']); ?>
                            </p>
                            <a href="adoption_form.php?cat_id=<?php echo $cat['id']; ?>" class="btn btn-warning w-100 fw-semibold">Adopt Me!</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<style>
.image-container {
    height: 250px;
    overflow: hidden;
    position: relative;
}

.image-container img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
}

.cat-card:hover .image-container img {
    transform: scale(1.05);
}

.cat-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.cat-card:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 0 6px 24px rgba(0,0,0,0.12);
}

.filter-card {
    background: linear-gradient(135deg, #e0e7ff 0%, #f8fafc 100%);
    border: none;
    border-radius: 20px;
    box-shadow: 0 2px 8px rgba(74,144,226,0.08);
}
</style>

<?php include 'includes/footer.php'; ?> 