<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $amount = trim($_POST['amount'] ?? '');
    $payment_method = trim($_POST['payment_method'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($amount) || empty($payment_method)) {
        $error_message = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address.';
    } elseif (!is_numeric($amount) || $amount <= 0) {
        $error_message = 'Please enter a valid donation amount.';
    } else {
        // Here you would typically process the payment
        // For now, we'll just show a success message
        $success_message = 'Thank you for your generous donation! We will process your payment shortly.';
    }
}
?>

<?php include 'includes/header.php'; ?>

<!-- Hero Banner -->
<div class="py-5 text-center" style="background: linear-gradient(135deg, #a6c1ee 0%, #fbc2eb 100%);">
    <div class="container">
        <h1 class="display-4 fw-bold mb-2">Make a Donation</h1>
        <p class="lead mb-0">Your support helps us provide better care for our feline friends.</p>
    </div>
</div>

<div class="container my-5">
    <div class="row g-5">
        <div class="col-lg-6">
            <div class="card donation-info-card border-0 shadow-lg rounded-4 h-100">
                <div class="card-body p-4">
                    <h2 class="mb-4">Why Donate?</h2>
                    <div class="donation-benefits">
                        <div class="d-flex align-items-center mb-4">
                            <i class="fas fa-heart fa-2x text-danger me-3"></i>
                            <div>
                                <h5 class="mb-1">Support Cat Care</h5>
                                <p class="mb-0 small">Help us provide medical care, food, and shelter for our rescued cats.</p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center mb-4">
                            <i class="fas fa-home fa-2x text-primary me-3"></i>
                            <div>
                                <h5 class="mb-1">Improve Facilities</h5>
                                <p class="mb-0 small">Your donations help us maintain and upgrade our shelter facilities.</p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center mb-4">
                            <i class="fas fa-paw fa-2x text-success me-3"></i>
                            <div>
                                <h5 class="mb-1">Rescue More Cats</h5>
                                <p class="mb-0 small">Enable us to rescue and care for more cats in need.</p>
                            </div>
                        </div>
                        <div class="d-flex align-items-center">
                            <i class="fas fa-graduation-cap fa-2x text-warning me-3"></i>
                            <div>
                                <h5 class="mb-1">Education Programs</h5>
                                <p class="mb-0 small">Support our community education initiatives about cat care.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card donation-form-card border-0 shadow-lg rounded-4">
                <div class="card-body p-4">
                    <h2 class="mb-4 text-center">Make Your Donation</h2>
                    <?php if ($success_message): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    <?php if ($error_message): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="name" class="form-label">Full Name *</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address *</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="amount" class="form-label">Donation Amount (MYR) *</label>
                            <div class="input-group">
                                <span class="input-group-text">RM</span>
                                <input type="number" class="form-control" id="amount" name="amount" min="1" step="0.01" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Payment Method *</label>
                            <div class="payment-methods">
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="payment_method" id="creditCard" value="credit_card" required>
                                    <label class="form-check-label" for="creditCard">
                                        <i class="fab fa-cc-visa me-2"></i>
                                        <i class="fab fa-cc-mastercard me-2"></i>
                                        Credit Card
                                    </label>
                                </div>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="payment_method" id="bankTransfer" value="bank_transfer">
                                    <label class="form-check-label" for="bankTransfer">
                                        <i class="fas fa-university me-2"></i>
                                        Bank Transfer
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" id="ewallet" value="e_wallet">
                                    <label class="form-check-label" for="ewallet">
                                        <i class="fas fa-wallet me-2"></i>
                                        E-Wallet (Touch 'n Go, GrabPay)
                                    </label>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Message (Optional)</label>
                            <textarea class="form-control" id="message" name="message" rows="3" placeholder="Share why you're donating..."></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-3 fw-bold fs-5 donation-button">
                            <i class="fas fa-heart me-2"></i> Donate Now
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.donation-info-card, .donation-form-card {
    border: none;
    border-radius: 20px;
    box-shadow: 0 4px 20px rgba(74,144,226,0.08);
    background: #fff;
    transition: transform 0.2s;
}
.donation-info-card:hover, .donation-form-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 24px rgba(0,0,0,0.12);
}
.payment-methods {
    background: #f8f9fa;
    padding: 1rem;
    border-radius: 10px;
}
.donation-button {
    background: linear-gradient(135deg, #ff6b6b 0%, #ff8e8e 100%);
    border: none;
    color: white;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
}
.donation-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 20px rgba(255, 107, 107, 0.4);
    background: linear-gradient(135deg, #ff5252 0%, #ff7676 100%);
    color: white;
}
.donation-button:active {
    transform: translateY(1px);
}
</style>

<?php include 'includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 