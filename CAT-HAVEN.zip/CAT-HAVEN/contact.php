<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $error_message = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address.';
    } else {
        // Here you would typically send the email
        // For now, we'll just show a success message
        $success_message = 'Thank you for your message. We will get back to you soon!';
    }
}
?>

<?php include 'includes/header.php'; ?>

<!-- Hero Banner -->
<div class="py-5 text-center" style="background: linear-gradient(135deg, #fbc2eb 0%, #a6c1ee 100%);">
    <div class="container">
        <h1 class="display-4 fw-bold mb-2">Contact Us</h1>
        <p class="lead mb-0">We'd love to hear from you! Reach out to us through any of these channels.</p>
    </div>
</div>

<div class="container my-5">
    <div class="row g-5">
        <div class="col-lg-6">
            <div class="row g-3 mb-4">
                <div class="col-12">
                    <div class="d-flex align-items-center bg-white rounded-4 shadow-sm p-3">
                        <i class="fas fa-map-marker-alt fa-2x text-primary me-3"></i>
                        <div>
                            <h5 class="mb-1">Visit Us</h5>
                            <p class="mb-0 small">
                                No. 123, Jalan Kucing,<br>
                                Taman Kucing Indah,<br>
                                50000 Kuala Lumpur,<br>
                                Wilayah Persekutuan Kuala Lumpur
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="d-flex align-items-center bg-white rounded-4 shadow-sm p-3">
                        <i class="fas fa-phone fa-2x text-success me-3"></i>
                        <div>
                            <h5 class="mb-1">Call Us</h5>
                            <p class="mb-0 small">
                                Main: +60 3-1234 5678<br>
                                Mobile: +60 12-345 6789
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="d-flex align-items-center bg-white rounded-4 shadow-sm p-3">
                        <i class="fas fa-envelope fa-2x text-warning me-3"></i>
                        <div>
                            <h5 class="mb-1">Email Us</h5>
                            <p class="mb-0 small">info@cathaven.com.my</p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="d-flex align-items-center bg-white rounded-4 shadow-sm p-3">
                        <i class="fas fa-clock fa-2x text-info me-3"></i>
                        <div>
                            <h5 class="mb-1">Operating Hours</h5>
                            <p class="mb-0 small">
                                Mon-Fri: 10:00 AM - 7:00 PM<br>
                                Sat: 10:00 AM - 5:00 PM<br>
                                Sun: 12:00 PM - 4:00 PM<br>
                                Public Holidays: Closed
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="d-flex align-items-center bg-white rounded-4 shadow-sm p-3">
                        <i class="fas fa-map fa-2x text-danger me-3"></i>
                        <div>
                            <h5 class="mb-1">How to Find Us</h5>
                            <p class="mb-0 small">
                                We are located near KLCC, just a 5-minute walk from the LRT station.<br>
                                Look for our cat-shaped signboard!
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="social-media mt-4">
                <h5>Follow Us</h5>
                <div class="d-flex gap-3">
                    <a href="#" class="text-primary"><i class="fab fa-facebook fa-2x"></i></a>
                    <a href="#" class="text-primary"><i class="fab fa-instagram fa-2x"></i></a>
                    <a href="#" class="text-primary"><i class="fab fa-twitter fa-2x"></i></a>
                    <a href="#" class="text-primary"><i class="fab fa-tiktok fa-2x"></i></a>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card contact-card border-0 shadow-lg rounded-4">
                <div class="card-body p-4">
                    <h2 class="mb-4 text-center">Send Us a Message</h2>
                    <?php if ($success_message): ?>
                        <div class="alert alert-success"><?php echo $success_message; ?></div>
                    <?php endif; ?>
                    <?php if ($error_message): ?>
                        <div class="alert alert-danger"><?php echo $error_message; ?></div>
                    <?php endif; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name *</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email *</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" placeholder="e.g., +60 12-345 6789">
                        </div>
                        <div class="mb-3">
                            <label for="subject" class="form-label">Subject *</label>
                            <input type="text" class="form-control" id="subject" name="subject" required>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Message *</label>
                            <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                            <i class="fas fa-paper-plane"></i> Send Message
                        </button>
                    </form>
                </div>
            </div>
            <!-- Google Maps Embed -->
            <div class="mt-4">
                <h5>Our Location</h5>
                <div class="ratio ratio-16x9 rounded-4 overflow-hidden shadow-sm">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3983.534355096907!2d101.686855!3d3.139003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31cc49c701efeae7%3A0xf4d98e5b2f1c287d!2sKuala%20Lumpur%20City%20Centre!5e0!3m2!1sen!2smy!4v1647881234567!5m2!1sen!2smy" 
                        style="border:0;" 
                        allowfullscreen="" 
                        loading="lazy">
                    </iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.contact-card {
    border: none;
    border-radius: 20px;
    box-shadow: 0 4px 20px rgba(74,144,226,0.08);
    background: #fff;
    transition: transform 0.2s;
}
.contact-card:hover {
    transform: translateY(-5px) scale(1.02);
    box-shadow: 0 6px 24px rgba(0,0,0,0.12);
}
</style>

<?php include 'includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script> 