<?php
require_once 'includes/config.php';

try {
    // Test database connection
    $stmt = $pdo->query("SELECT 1");
    echo "Database connection successful!<br>";
    
    // Test cats table
    $stmt = $pdo->query("SELECT COUNT(*) FROM cats");
    $count = $stmt->fetchColumn();
    echo "Number of cats in database: " . $count . "<br>";
    
    // Test adoption_applications table
    $stmt = $pdo->query("SELECT COUNT(*) FROM adoption_applications");
    $count = $stmt->fetchColumn();
    echo "Number of adoption applications: " . $count . "<br>";
    
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?> 