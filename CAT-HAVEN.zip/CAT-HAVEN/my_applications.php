<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Require user authentication
requireLogin();

// Handle update form submission
$update_success = null;
$update_error = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['application_id'])) {
    $application_id = $_POST['application_id'];
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $occupation = trim($_POST['occupation'] ?? '');
    $experience = trim($_POST['experience'] ?? '');
    $reason = trim($_POST['reason'] ?? '');

    // Basic validation
    if (empty($first_name) || empty($last_name) || empty($email) || empty($phone) || empty($address) || empty($occupation) || empty($experience) || empty($reason)) {
        $update_error = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $update_error = 'Please enter a valid email address.';
    } else {
        // Update the application in the database
        $stmt = $pdo->prepare("UPDATE adoption_applications SET first_name=?, last_name=?, email=?, phone=?, address=?, occupation=?, experience=?, reason=? WHERE id=? AND user_id=?");
        if ($stmt->execute([$first_name, $last_name, $email, $phone, $address, $occupation, $experience, $reason, $application_id, getCurrentUserId()])) {
            $update_success = 'Your application has been updated successfully!';
        } else {
            $update_error = 'Failed to update your application. Please try again.';
        }
    }
}

// Get current user's ID
$user_id = getCurrentUserId();

// Get filter parameters
$status_filter = $_GET['status'] ?? '';

// Build the query
$query = "SELECT a.*, c.name as cat_name, c.breed, c.image 
          FROM adoption_applications a 
          JOIN cats c ON a.cat_id = c.id 
          WHERE a.user_id = ?";
$params = [$user_id];

if ($status_filter) {
    $query .= " AND a.status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY a.created_at DESC";

// Fetch applications
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$applications = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Adoption Applications - Cat Haven</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e0e7ff 100%);
            min-height: 100vh;
        }
        .app-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(74,144,226,0.08);
            background: #fff;
            transition: transform 0.2s;
        }
        .app-card:hover {
            transform: translateY(-5px) scale(1.02);
        }
        .status-badge {
            border-radius: 20px;
            padding: 0.4rem 1.2rem;
            font-weight: 600;
            font-size: 1rem;
        }
        .status-pending {
            background: #fff3cd;
            color: #856404;
        }
        .status-approved {
            background: #d4edda;
            color: #155724;
        }
        .status-rejected {
            background: #f8d7da;
            color: #721c24;
        }
        .btn-primary {
            background: linear-gradient(135deg, #ff9800 0%, #ffc107 100%);
            border: none;
            border-radius: 10px;
            font-weight: 600;
            padding: 0.5rem 1.5rem;
            font-size: 1rem;
            box-shadow: 0 2px 8px rgba(255,193,7,0.12);
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <div class="row mb-4">
            <div class="col-md-8">
                <h1>My Adoption Applications</h1>
            </div>
            <div class="col-md-4">
                <form method="GET" class="d-flex">
                    <select name="status" class="form-select me-2" onchange="this.form.submit()">
                        <option value="">All Applications</option>
                        <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="approved" <?php echo $status_filter === 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="rejected" <?php echo $status_filter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                </form>
            </div>
        </div>

        <?php if ($update_success): ?>
            <div class="alert alert-success"><?php echo $update_success; ?></div>
        <?php elseif ($update_error): ?>
            <div class="alert alert-danger"><?php echo $update_error; ?></div>
        <?php endif; ?>

        <?php if (empty($applications)): ?>
            <div class="alert alert-info">
                You haven't submitted any adoption applications yet. 
                <a href="adoption.php" class="alert-link">Browse available cats</a> to start your adoption journey!
            </div>
        <?php else: ?>
            <div class="row">
                <?php foreach ($applications as $app): ?>
                    <div class="col-md-6 mb-4">
                        <div class="card h-100">
                            <div class="row g-0">
                                <div class="col-md-4">
                                    <?php
                                    $image_path = 'assets/uploads/' . $app['image'];
                                    $default_image = 'assets/images/default-cat.jpg';
                                    ?>
                                    <img src="<?php echo file_exists($image_path) ? $image_path : $default_image; ?>" 
                                         class="img-fluid rounded-start h-100" 
                                         alt="<?php echo htmlspecialchars($app['cat_name']); ?>"
                                         style="object-fit: cover;">
                                </div>
                                <div class="col-md-8">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between align-items-start">
                                            <h5 class="card-title"><?php echo htmlspecialchars($app['cat_name']); ?></h5>
                                            <span class="badge bg-<?php 
                                                echo $app['status'] === 'approved' ? 'success' : 
                                                    ($app['status'] === 'rejected' ? 'danger' : 'warning'); 
                                            ?>">
                                                <?php echo ucfirst(htmlspecialchars($app['status'])); ?>
                                            </span>
                                        </div>
                                        <p class="card-text">
                                            <small class="text-muted">
                                                Applied on: <?php echo date('F d, Y', strtotime($app['created_at'])); ?>
                                            </small>
                                        </p>
                                        <p class="card-text">
                                            <strong>Breed:</strong> <?php echo htmlspecialchars($app['breed']); ?><br>
                                            <strong>Status:</strong> 
                                            <?php
                                            switch($app['status']) {
                                                case 'pending':
                                                    echo 'Your application is being reviewed.';
                                                    break;
                                                case 'approved':
                                                    echo 'Congratulations! Your application has been approved.';
                                                    break;
                                                case 'rejected':
                                                    echo 'We regret to inform you that your application was not approved.';
                                                    break;
                                            }
                                            ?>
                                        </p>
                                        <button type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#viewModal<?php echo $app['id']; ?>">
                                            <i class="fas fa-eye"></i> View Details
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- View Modal -->
                    <div class="modal fade" id="viewModal<?php echo $app['id']; ?>" tabindex="-1">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <form method="POST" action="my_applications.php">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Application Details</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h6>Your Information</h6>
                                                <div class="mb-2">
                                                    <label class="form-label"><strong>First Name:</strong></label>
                                                    <input type="text" class="form-control" name="first_name" value="<?php echo htmlspecialchars($app['first_name']); ?>" required>
                                                </div>
                                                <div class="mb-2">
                                                    <label class="form-label"><strong>Last Name:</strong></label>
                                                    <input type="text" class="form-control" name="last_name" value="<?php echo htmlspecialchars($app['last_name']); ?>" required>
                                                </div>
                                                <div class="mb-2">
                                                    <label class="form-label"><strong>Email:</strong></label>
                                                    <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($app['email']); ?>" required>
                                                </div>
                                                <div class="mb-2">
                                                    <label class="form-label"><strong>Phone:</strong></label>
                                                    <input type="text" class="form-control" name="phone" value="<?php echo htmlspecialchars($app['phone']); ?>" required>
                                                </div>
                                                <div class="mb-2">
                                                    <label class="form-label"><strong>Address:</strong></label>
                                                    <input type="text" class="form-control" name="address" value="<?php echo htmlspecialchars($app['address']); ?>" required>
                                                </div>
                                                <div class="mb-2">
                                                    <label class="form-label"><strong>Occupation:</strong></label>
                                                    <input type="text" class="form-control" name="occupation" value="<?php echo htmlspecialchars($app['occupation']); ?>" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <h6>Cat Information</h6>
                                                <p>
                                                    <strong>Name:</strong> <?php echo htmlspecialchars($app['cat_name']); ?><br>
                                                    <strong>Breed:</strong> <?php echo htmlspecialchars($app['breed']); ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-12">
                                                <h6>Your Experience with Pets</h6>
                                                <textarea class="form-control" name="experience" rows="2" required><?php echo htmlspecialchars($app['experience']); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-12">
                                                <h6>Your Reason for Adoption</h6>
                                                <textarea class="form-control" name="reason" rows="2" required><?php echo htmlspecialchars($app['reason']); ?></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <button type="submit" class="btn btn-primary">Save Changes</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 