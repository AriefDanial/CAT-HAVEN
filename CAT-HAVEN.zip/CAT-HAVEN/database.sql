-- Create the database
CREATE DATABASE IF NOT EXISTS cat_adoption;
USE cat_adoption;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('user', 'admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create cats table
CREATE TABLE IF NOT EXISTS cats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    breed VARCHAR(100) NOT NULL,
    gender ENUM('Male', 'Female') NOT NULL,
    status ENUM('available', 'adopted', 'pending') DEFAULT 'available',
    description TEXT NOT NULL,
    image VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create adoption_applications table
CREATE TABLE IF NOT EXISTS adoption_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cat_id INT NOT NULL,
    user_id INT NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    address TEXT NOT NULL,
    occupation VARCHAR(100) NOT NULL,
    experience TEXT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (cat_id) REFERENCES cats(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Create stray_cat_reports table
CREATE TABLE IF NOT EXISTS stray_cat_reports (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    location VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    contact_info VARCHAR(255) NOT NULL,
    image VARCHAR(255),
    status ENUM('pending', 'reviewed', 'rescued', 'closed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    report_id INT,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (report_id) REFERENCES stray_cat_reports(id) ON DELETE CASCADE
);

-- Insert sample data
INSERT INTO cats (name, age, breed, gender, description, image) VALUES
('Luna', 2, 'Persian', 'Female', 'A beautiful Persian cat with a gentle personality. Loves to cuddle and play with toys.', 'luna.jpg'),
('Oliver', 3, 'Maine Coon', 'Male', 'A majestic Maine Coon with a friendly disposition. Great with children and other pets.', 'oliver.jpg'),
('Bella', 1, 'Siamese', 'Female', 'An elegant Siamese cat with striking blue eyes. Very intelligent and affectionate.', 'bella.jpg');

-- Insert admin user (password: admin123) only if it doesn't exist
INSERT IGNORE INTO users (username, email, password, role) VALUES
('admin', 'admin@cathaven.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'); 