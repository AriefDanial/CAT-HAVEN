<?php
require_once 'includes/config.php';

// Fetch all cats from database
$stmt = $pdo->query("SELECT * FROM cats ORDER BY name");
$cats = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat Profiles - Cat Haven</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e0e7ff 100%);
            min-height: 100vh;
        }
        .profile-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(74,144,226,0.08);
            transition: transform 0.2s;
            background: #fff;
        }
        .profile-card:hover {
            transform: translateY(-5px) scale(1.02);
        }
        .profile-img {
            border-radius: 15px;
            box-shadow: 0 2px 8px rgba(74,144,226,0.10);
        }
        .btn-primary {
            background: linear-gradient(135deg, #ff9800 0%, #ffc107 100%);
            border: none;
            border-radius: 10px;
            font-weight: 600;
            padding: 0.5rem 1.5rem;
            font-size: 1rem;
            box-shadow: 0 2px 8px rgba(255,193,7,0.12);
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <h1 class="mb-4">Cat Profiles</h1>
        
        <div class="row">
            <?php foreach ($cats as $cat): ?>
            <div class="col-md-6 mb-4">
                <div class="card profile-card">
                    <div class="row g-0">
                        <div class="col-md-4">
                        <img src="assets/uploads/<?php echo htmlspecialchars($cat['image']); ?>" class="img-fluid rounded-start h-100 profile-img" alt="<?php echo htmlspecialchars($cat['name']); ?>" style="object-fit: cover;">
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($cat['name']); ?></h5>
                                <p class="card-text">
                                    <strong>Age:</strong> <?php echo htmlspecialchars($cat['age']); ?> years<br>
                                    <strong>Breed:</strong> <?php echo htmlspecialchars($cat['breed']); ?><br>
                                    <strong>Gender:</strong> <?php echo htmlspecialchars($cat['gender']); ?><br>
                                    <strong>Status:</strong> 
                                    <span class="badge <?php echo $cat['status'] === 'available' ? 'bg-success' : ($cat['status'] === 'pending' ? 'bg-warning' : 'bg-secondary'); ?>">
                                        <?php echo ucfirst(htmlspecialchars($cat['status'])); ?>
                                    </span>
                                </p>
                                <p class="card-text"><?php echo htmlspecialchars($cat['description']); ?></p>
                                <?php if ($cat['status'] === 'available'): ?>
                                <a href="adoption_form.php?cat_id=<?php echo $cat['id']; ?>" class="btn btn-primary">Adopt Me</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 