<?php
require_once 'includes/config.php';
require_once 'includes/auth.php'; // Added for user authentication

requireLogin(); // Ensure user is logged in to apply

if (!isset($_GET['cat_id'])) {
    header('Location: adoption.php');
    exit();
}

$cat_id = $_GET['cat_id'];
$stmt = $pdo->prepare("SELECT * FROM cats WHERE id = ?");
$stmt->execute([$cat_id]);
$cat = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$cat) {
    header('Location: adoption.php');
    exit();
}

$user_id = getCurrentUserId(); // Get current user's ID

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // $name = $_POST['name']; // Old field
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $occupation = trim($_POST['occupation'] ?? '');
    $experience = trim($_POST['experience'] ?? '');
    // $reason = $_POST['reason']; // This was the old 'experience' field, let's map it
    $reason_for_adoption = trim($_POST['reason_for_adoption'] ?? '');


    if (empty($first_name) || empty($last_name) || empty($email) || empty($phone) || empty($address) || empty($occupation) || empty($experience) || empty($reason_for_adoption) || empty($user_id)) {
        $error = "Please fill in all required fields.";
    } else {
        try {
            // $stmt = $pdo->prepare("INSERT INTO adoption_applications (cat_id, name, email, phone, address, reason, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
            // $stmt->execute([$cat_id, $name, $email, $phone, $address, $reason]);
            $stmt = $pdo->prepare(
                "INSERT INTO adoption_applications (cat_id, user_id, first_name, last_name, email, phone, address, occupation, experience, reason, status) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')"
            );
            $stmt->execute([$cat_id, $user_id, $first_name, $last_name, $email, $phone, $address, $occupation, $experience, $reason_for_adoption]);
            $success = true;
        } catch(PDOException $e) {
            $error = "Error submitting application: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adoption Application - Cat Haven</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e0e7ff 100%);
            min-height: 100vh;
        }
        .form-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(74,144,226,0.08);
            background: #fff;
        }
        .form-label {
            font-weight: 500;
            color: #495057;
        }
        .form-control, .form-select {
            border-radius: 10px;
            padding: 0.8rem 1rem;
            border: 1px solid #dee2e6;
            transition: all 0.3s ease;
        }
        .form-control:focus, .form-select:focus {
            box-shadow: 0 0 0 0.2rem rgba(74, 144, 226, 0.25);
            border-color: #4a90e2;
        }
        .btn-primary {
            background: linear-gradient(135deg, #ff9800 0%, #ffc107 100%);
            border: none;
            border-radius: 10px;
            font-weight: 600;
            padding: 0.75rem 2rem;
            font-size: 1.1rem;
            box-shadow: 0 2px 8px rgba(255,193,7,0.12);
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <h1 class="mb-4">Adoption Application for <?php echo htmlspecialchars($cat['name']); ?></h1>

        <?php if (isset($success)): ?>
            <div class="alert alert-success">
                Your application has been submitted successfully! We will contact you soon.
            </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger">
                <?php echo $error; ?>
            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-6">
                <div class="card mb-4">
                    <?php if (!empty($cat['image'])): ?>
                        <img src="assets/uploads/<?php echo htmlspecialchars($cat['image']); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($cat['name']); ?>" style="object-fit:cover;max-height:300px;">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo htmlspecialchars(
                            $cat['name']); ?></h5>
                        <p class="card-text">
                            <strong>Age:</strong> <?php echo htmlspecialchars($cat['age']); ?> years<br>
                            <strong>Breed:</strong> <?php echo htmlspecialchars($cat['breed']); ?><br>
                            <strong>Gender:</strong> <?php echo htmlspecialchars($cat['gender']); ?>
                        </p>
                        <hr>
                        <blockquote class="blockquote text-center mt-4">
                            <p class="mb-0">"Time spent with cats is never wasted."</p>
                            <footer class="blockquote-footer">Sigmund Freud</footer>
                        </blockquote>
                    </div>
                </div>
            </div>

            <div class="col-md-6">
                <form method="POST" class="card">
                    <div class="card-body">
                        <h5 class="card-title">Adoption Application Form</h5>
                        
                        <div class="mb-3">
                            <label for="first_name" class="form-label">First Name</label>
                            <input type="text" class="form-control" id="first_name" name="first_name" required value="<?php echo htmlspecialchars($_POST['first_name'] ?? ''); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="last_name" class="form-label">Last Name</label>
                            <input type="text" class="form-control" id="last_name" name="last_name" required value="<?php echo htmlspecialchars($_POST['last_name'] ?? ''); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email Address</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>

                        <div class="mb-3">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" required>
                        </div>

                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <textarea class="form-control" id="address" name="address" rows="3" required></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="occupation" class="form-label">Occupation</label>
                            <input type="text" class="form-control" id="occupation" name="occupation" required value="<?php echo htmlspecialchars($_POST['occupation'] ?? ''); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="experience" class="form-label">Experience with Pets</label>
                            <textarea class="form-control" id="experience" name="experience" rows="4" required><?php echo htmlspecialchars($_POST['experience'] ?? ''); ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="reason_for_adoption" class="form-label">Why do you want to adopt this cat?</label>
                            <textarea class="form-control" id="reason_for_adoption" name="reason_for_adoption" rows="4" required><?php echo htmlspecialchars($_POST['reason_for_adoption'] ?? ''); ?></textarea>
                        </div>

                        <button type="submit" class="btn btn-primary">Submit Application</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 