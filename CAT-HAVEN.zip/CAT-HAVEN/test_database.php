<?php
require_once 'includes/config.php';

try {
    // Test database connection
    echo "Testing database connection...<br>";
    $stmt = $pdo->query("SELECT 1");
    echo "Database connection successful!<br><br>";

    // Check if adoption_applications table exists
    echo "Checking adoption_applications table...<br>";
    $stmt = $pdo->query("SHOW TABLES LIKE 'adoption_applications'");
    if ($stmt->rowCount() > 0) {
        echo "adoption_applications table exists!<br><br>";
        
        // Check table structure
        echo "Table structure:<br>";
        $stmt = $pdo->query("DESCRIBE adoption_applications");
        echo "<pre>";
        while ($row = $stmt->fetch()) {
            print_r($row);
        }
        echo "</pre>";
    } else {
        echo "adoption_applications table does not exist!<br>";
    }

    // Check if users table exists
    echo "<br>Checking users table...<br>";
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() > 0) {
        echo "users table exists!<br><br>";
        
        // Check table structure
        echo "Table structure:<br>";
        $stmt = $pdo->query("DESCRIBE users");
        echo "<pre>";
        while ($row = $stmt->fetch()) {
            print_r($row);
        }
        echo "</pre>";
    } else {
        echo "users table does not exist!<br>";
    }

} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?> 