<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4 mb-md-0">
                <h5 class="text-white mb-4">
                    <i class="fas fa-cat"></i> Cat Haven
                </h5>
                <p class="text-light mb-4">
                    Dedicated to finding loving homes for cats in need. Join us in our mission to provide care and shelter for every cat.
                </p>
                <div class="social-links">
                    <a href="#" class="text-light me-3"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="text-light me-3"><i class="fab fa-twitter"></i></a>
                    <a href="#" class="text-light me-3"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="text-light"><i class="fab fa-youtube"></i></a>
                </div>
            </div>
            <div class="col-md-4 mb-4 mb-md-0">
                <h5 class="text-white mb-4">Quick Links</h5>
                <ul class="list-unstyled">
                    <li class="mb-2">
                        <a href="/cat-haven/adoption.php" class="text-light text-decoration-none">
                            <i class="fas fa-paw me-2"></i> Adopt a Cat
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="/cat-haven/care.php" class="text-light text-decoration-none">
                            <i class="fas fa-heart me-2"></i> Cat Care
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="/cat-haven/donation.php" class="text-light text-decoration-none">
                            <i class="fas fa-donate me-2"></i> Donate
                        </a>
                    </li>
                    <li class="mb-2">
                        <a href="/cat-haven/contact.php" class="text-light text-decoration-none">
                            <i class="fas fa-envelope me-2"></i> Contact Us
                        </a>
                    </li>
                </ul>
            </div>
            <div class="col-md-4">
                <h5 class="text-white mb-4">Contact Info</h5>
                <ul class="list-unstyled text-light">
                    <li class="mb-2">
                        <i class="fas fa-map-marker-alt me-2"></i>
                        123 Cat Street, Meow City
                    </li>
                    <li class="mb-2">
                        <i class="fas fa-phone me-2"></i>
                        (123) 456-7890
                    </li>
                    <li class="mb-2">
                        <i class="fas fa-envelope me-2"></i>
                        info@cathaven.com
                    </li>
                    <li>
                        <i class="fas fa-clock me-2"></i>
                        Mon - Fri: 9:00 AM - 6:00 PM
                    </li>
                </ul>
            </div>
        </div>
        <hr class="mt-4 mb-4" style="border-color: rgba(255,255,255,0.1);">
        <div class="row">
            <div class="col-md-6 text-center text-md-start">
                <p class="text-light mb-0">
                    &copy; <?php echo date('Y'); ?> Cat Haven. All rights reserved.
                </p>
            </div>
            <div class="col-md-6 text-center text-md-end">
                <a href="#" class="text-light text-decoration-none me-3">Privacy Policy</a>
                <a href="#" class="text-light text-decoration-none">Terms of Service</a>
            </div>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 