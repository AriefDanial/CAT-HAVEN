<?php
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Expires: 0');

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat Haven - Find Your Perfect Feline Friend</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="/cat-haven/assets/css/style.css">
    <style>
    .navbar {
        z-index: 1050 !important;
        position: relative;
    }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary position-relative">
        <div class="container position-relative">
            <a class="navbar-brand" href="/cat-haven/index.php">
                <i class="fas fa-cat"></i> Cat Haven
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="/cat-haven/index.php">
                            <i class="fas fa-home"></i> Home
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/cat-haven/adoption.php">
                            <i class="fas fa-paw"></i> Adopt
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/cat-haven/care.php">
                            <i class="fas fa-heart"></i> Cat Care
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/cat-haven/events.php">
                            <i class="fas fa-calendar-alt"></i> Events
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/cat-haven/donation.php">
                            <i class="fas fa-donate"></i> Donate
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/cat-haven/report_cat.php">
                            <i class="fas fa-exclamation-circle"></i> Report Stray Cat
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/cat-haven/contact.php">
                            <i class="fas fa-envelope"></i> Contact
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <?php if (isLoggedIn()): ?>
                        <?php if (isAdmin()): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="/cat-haven/admin/index.php">
                                    <i class="fas fa-user-shield"></i> Admin Panel
                                </a>
                            </li>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/cat-haven/my_applications.php">
                                <i class="fas fa-file-alt"></i> My Applications
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/cat-haven/my_reports.php">
                                <i class="fas fa-exclamation-circle"></i> My Reports
                            </a>
                        </li>
                        <li class="nav-item">
                            <span class="nav-link">
                                <i class="fas fa-user"></i> Welcome, <?php echo htmlspecialchars(getCurrentUsername()); ?>
                            </span>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/cat-haven/logout.php">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="/cat-haven/login.php">
                                <i class="fas fa-sign-in-alt"></i> Login
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/cat-haven/register.php">
                                <i class="fas fa-user-plus"></i> Register
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 