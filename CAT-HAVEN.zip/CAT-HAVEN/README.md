# Cat Haven - Cat Adoption Website

A fully functional website for cat adoption and cat care information, built with PHP and MySQL.

## Features

- Cat adoption listings
- Detailed cat profiles
- Adoption application system
- Cat care information
- Responsive design
- Admin panel for managing cats and applications

## Requirements

- XAMPP (Apache, MySQL, PHP)
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web browser

## Installation

1. Install XAMPP on your system
2. Clone or download this repository to your `htdocs` folder
3. Start Apache and MySQL services in XAMPP Control Panel
4. Open phpMyAdmin (http://localhost/phpmyadmin)
5. Create a new database named `cat_haven`
6. Import the `database.sql` file into your database
7. Access the website through your browser at `http://localhost/cat-haven`

## Directory Structure

```
cat-haven/
├── assets/
│   ├── css/
│   │   └── style.css
│   └── images/
│       └── cats/
├── includes/
│   ├── config.php
│   ├── header.php
│   └── footer.php
├── index.php
├── adoption.php
├── adoption_form.php
├── profiles.php
├── care.php
├── contact.php
└── database.sql
```

## Database Structure

The database consists of two main tables:

1. `cats` - Stores information about available cats
2. `adoption_applications` - Stores adoption applications

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, please email support@cathaven.com or create an issue in the repository. 