<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Require user authentication
requireLogin();

$success_message = '';
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $location = trim($_POST['location'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $contact_info = trim($_POST['contact_info'] ?? '');
    $user_id = getCurrentUserId();

    // Validate input
    if (empty($location) || empty($description) || empty($contact_info)) {
        $error_message = "Please fill in all required fields.";
    } else {
        // Handle image upload
        $image = '';
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $upload_dir = 'assets/uploads/reports/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];

            if (!in_array($file_extension, $allowed_extensions)) {
                $error_message = "Invalid file type. Please upload a JPG, JPEG, PNG, or GIF image.";
            } else {
                $image = uniqid('report_') . '.' . $file_extension;
                $upload_path = $upload_dir . $image;

                if (!move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                    $error_message = "Error uploading image.";
                }
            }
        }

        if (empty($error_message)) {
            // Insert report into database
            $stmt = $pdo->prepare("INSERT INTO stray_cat_reports (user_id, location, description, contact_info, image, status) VALUES (?, ?, ?, ?, ?, 'pending')");
            
            if ($stmt->execute([$user_id, $location, $description, $contact_info, $image])) {
                $success_message = "Stray cat report submitted successfully! Our team will review it shortly.";
                // Clear form data
                $location = $description = $contact_info = '';
            } else {
                $error_message = "Error submitting report. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Report Stray Cat - Cat Haven</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            font-family: 'Poppins', Arial, sans-serif;
        }
        .page-header {
            background: linear-gradient(135deg, #4a90e2 0%, #6a5acd 100%);
            color: white;
            padding: 3rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .form-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .form-card .card-body {
            padding: 2rem;
        }
        .required-field::after {
            content: " *";
            color: #dc3545;
        }
        .image-preview {
            width: 200px;
            height: 200px;
            border-radius: 10px;
            object-fit: cover;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            display: none;
        }
        .btn-primary {
            background: linear-gradient(135deg, #4a90e2 0%, #6a5acd 100%);
            border: none;
        }
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d 0%, #495057 100%);
            border: none;
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="page-header">
        <div class="container">
            <h1 class="display-4 mb-0">Report a Stray Cat</h1>
            <p class="lead mb-0">Help us help stray cats by reporting their location</p>
        </div>
    </div>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="form-card card">
                    <div class="card-body">
                        <?php if ($success_message): ?>
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo $success_message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>
                        <?php if ($error_message): ?>
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                <?php echo $error_message; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <form method="POST" enctype="multipart/form-data" id="reportForm">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="location" class="form-label required-field">Location</label>
                                        <input type="text" class="form-control" id="location" name="location" required 
                                               placeholder="Enter the exact location where you saw the cat"
                                               value="<?php echo htmlspecialchars($location ?? ''); ?>">
                                    </div>

                                    <div class="mb-4">
                                        <label for="contact_info" class="form-label required-field">Contact Information</label>
                                        <input type="text" class="form-control" id="contact_info" name="contact_info" required
                                               placeholder="Your phone number or email"
                                               value="<?php echo htmlspecialchars($contact_info ?? ''); ?>">
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="mb-4">
                                        <label for="image" class="form-label">Cat Photo</label>
                                        <input type="file" class="form-control" id="image" name="image" 
                                               accept="image/*" onchange="previewImage(this)">
                                        <div class="form-text">Upload a clear photo of the stray cat if possible</div>
                                        <img id="imagePreview" class="image-preview mt-3" alt="Image preview">
                                    </div>

                                    <div class="mb-4">
                                        <label for="description" class="form-label required-field">Description</label>
                                        <textarea class="form-control" id="description" name="description" 
                                                  rows="4" required
                                                  placeholder="Describe the cat's appearance, condition, and any other relevant details"><?php echo htmlspecialchars($description ?? ''); ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between mt-4">
                                <a href="index.php" class="btn btn-secondary">
                                    <i class="fas fa-arrow-left"></i> Back to Home
                                </a>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-paper-plane"></i> Submit Report
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function previewImage(input) {
            const preview = document.getElementById('imagePreview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(input.files[0]);
            } else {
                preview.style.display = 'none';
            }
        }
    </script>
</body>
</html> 