<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat Haven - Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e0e7ff 100%);
            min-height: 100vh;
        }
        .hero {
            background: linear-gradient(135deg, #6a5acd 0%, #4a90e2 100%);
            color: #fff;
            border-radius: 0 0 30px 30px;
            box-shadow: 0 4px 20px rgba(74,144,226,0.08);
            padding: 3rem 1rem 2rem 1rem;
            text-align: center;
        }
        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }
        .hero p {
            font-size: 1.3rem;
            font-weight: 400;
        }
        .main-content {
            margin-top: 2rem;
        }
        .card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(74,144,226,0.08);
            transition: transform 0.2s;
        }
        .card:hover {
            transform: translateY(-5px) scale(1.02);
        }
        .btn-primary {
            background: linear-gradient(135deg, #ff9800 0%, #ffc107 100%);
            border: none;
            border-radius: 10px;
            font-weight: 600;
            padding: 0.75rem 2rem;
            font-size: 1.1rem;
            box-shadow: 0 2px 8px rgba(255,193,7,0.12);
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Section -->
    <div class="hero-section position-relative text-center py-5" style="background: linear-gradient(135deg, #6a5acd 0%, #4a90e2 100%); color: #fff; min-height: 400px;">
        <div class="container position-relative z-2">
            <h1 class="display-3 fw-bold mb-3">Welcome to Cat Haven</h1>
            <p class="lead mb-4">Find your perfect feline companion or learn more about our cat care services.</p>
            <a class="btn btn-lg btn-warning px-5 py-3 fw-semibold shadow" href="adoption.php">View Available Cats</a>
        </div>
    </div>

    <!-- Quick Stats Section -->
    <div class="container my-5">
        <div class="row text-center g-4">
            <div class="col-md-3 col-6">
                <div class="bg-white rounded-4 shadow p-4 h-100 d-flex flex-column align-items-center justify-content-center">
                    <i class="fas fa-cat fa-2x text-primary mb-2"></i>
                    <h3 class="fw-bold mb-0">120+</h3>
                    <small class="text-muted">Cats Adopted</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="bg-white rounded-4 shadow p-4 h-100 d-flex flex-column align-items-center justify-content-center">
                    <i class="fas fa-paw fa-2x text-warning mb-2"></i>
                    <h3 class="fw-bold mb-0">30</h3>
                    <small class="text-muted">Available Cats</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="bg-white rounded-4 shadow p-4 h-100 d-flex flex-column align-items-center justify-content-center">
                    <i class="fas fa-users fa-2x text-success mb-2"></i>
                    <h3 class="fw-bold mb-0">200+</h3>
                    <small class="text-muted">Happy Families</small>
                </div>
            </div>
            <div class="col-md-3 col-6">
                <div class="bg-white rounded-4 shadow p-4 h-100 d-flex flex-column align-items-center justify-content-center">
                    <i class="fas fa-calendar-check fa-2x text-info mb-2"></i>
                    <h3 class="fw-bold mb-0">5 Years</h3>
                    <small class="text-muted">Of Service</small>
                </div>
            </div>
        </div>
    </div>

    <!-- Features Section -->
    <div class="container my-5">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card h-100 text-center border-0 shadow-lg rounded-4">
                    <div class="card-body py-5">
                        <i class="fas fa-heart fa-3x text-danger mb-3"></i>
                        <h4 class="card-title fw-bold mb-3">Adopt a Cat</h4>
                        <p class="card-text">Find your perfect feline companion from our selection of loving cats.</p>
                        <a href="adoption.php" class="btn btn-outline-primary mt-2">Learn More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 text-center border-0 shadow-lg rounded-4">
                    <div class="card-body py-5">
                        <i class="fas fa-id-badge fa-3x text-primary mb-3"></i>
                        <h4 class="card-title fw-bold mb-3">Cat Profiles</h4>
                        <p class="card-text">Learn about our cats' personalities, stories, and special needs.</p>
                        <a href="profiles.php" class="btn btn-outline-primary mt-2">View Profiles</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 text-center border-0 shadow-lg rounded-4">
                    <div class="card-body py-5">
                        <i class="fas fa-stethoscope fa-3x text-success mb-3"></i>
                        <h4 class="card-title fw-bold mb-3">Cat Care</h4>
                        <p class="card-text">Resources and tips for taking care of your feline friend.</p>
                        <a href="care.php" class="btn btn-outline-primary mt-2">Learn More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Testimonials Section -->
    <div class="container my-5">
        <h2 class="text-center mb-4 fw-bold">Happy Tails & Success Stories</h2>
        <div class="row g-4 justify-content-center">
            <div class="col-md-4">
                <blockquote class="blockquote p-4 bg-white rounded-4 shadow text-center h-100">
                    <p class="mb-3">"Adopting Luna was the best decision ever! She brings so much joy to our family."</p>
                    <footer class="blockquote-footer fw-bold">Sarah L. <cite class="fw-normal">Adopted Luna</cite></footer>
                </blockquote>
            </div>
            <div class="col-md-4">
                <blockquote class="blockquote p-4 bg-white rounded-4 shadow text-center h-100">
                    <p class="mb-3">"Cat Haven made the adoption process so easy. Oliver is now my best friend!"</p>
                    <footer class="blockquote-footer fw-bold">James K. <cite class="fw-normal">Adopted Oliver</cite></footer>
                </blockquote>
            </div>
            <div class="col-md-4">
                <blockquote class="blockquote p-4 bg-white rounded-4 shadow text-center h-100">
                    <p class="mb-3">"Thank you Cat Haven for helping us find Bella. She fits right in!"</p>
                    <footer class="blockquote-footer fw-bold">Maria P. <cite class="fw-normal">Adopted Bella</cite></footer>
                </blockquote>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 