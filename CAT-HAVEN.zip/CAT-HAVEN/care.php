<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cat Care - Cat Haven</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            font-family: 'Poppins', Arial, sans-serif;
            background: linear-gradient(135deg, #f8fafc 0%, #e0e7ff 100%);
            min-height: 100vh;
        }
        .care-card {
            border: none;
            border-radius: 20px;
            box-shadow: 0 4px 20px rgba(74,144,226,0.08);
            background: #fff;
            transition: transform 0.2s;
        }
        .care-card:hover {
            transform: translateY(-5px) scale(1.02);
            box-shadow: 0 6px 24px rgba(0,0,0,0.12);
        }
        .btn-primary {
            background: linear-gradient(135deg, #ff9800 0%, #ffc107 100%);
            border: none;
            border-radius: 10px;
            font-weight: 600;
            padding: 0.5rem 1.5rem;
            font-size: 1rem;
            box-shadow: 0 2px 8px rgba(255,193,7,0.12);
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
        }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <!-- Hero Banner -->
    <div class="py-5 text-center" style="background: linear-gradient(135deg, #e0c3fc 0%, #8ec5fc 100%);">
        <div class="container">
            <h1 class="display-4 fw-bold mb-2">Cat Care Guide</h1>
            <p class="lead mb-0">Tips and resources to keep your feline friend happy and healthy!</p>
        </div>
    </div>

    <div class="container my-5">
        <div class="row g-4">
            <div class="col-md-4">
                <div class="card care-card h-100 text-center border-0 shadow-lg rounded-4">
                    <div class="card-body py-5">
                        <i class="fas fa-utensils fa-3x text-warning mb-3"></i>
                        <h5 class="card-title fw-bold mb-3">Nutrition</h5>
                        <ul class="list-unstyled mb-2">
                            <li><strong>Feeding Schedule:</strong></li>
                            <li>Kittens (under 6 months): 3-4 times daily</li>
                            <li>Adult cats: 2 times daily</li>
                            <li>Senior cats: 2-3 times daily</li>
                        </ul>
                        <ul class="list-unstyled">
                            <li><strong>Diet Tips:</strong></li>
                            <li>Provide fresh water daily</li>
                            <li>Choose high-quality cat food</li>
                            <li>Avoid human food and toxic items</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card care-card h-100 text-center border-0 shadow-lg rounded-4">
                    <div class="card-body py-5">
                        <i class="fas fa-shower fa-3x text-info mb-3"></i>
                        <h5 class="card-title fw-bold mb-3">Health & Grooming</h5>
                        <ul class="list-unstyled mb-2">
                            <li><strong>Regular Care:</strong></li>
                            <li>Brush fur regularly</li>
                            <li>Trim nails monthly</li>
                            <li>Clean ears and eyes</li>
                            <li>Dental care</li>
                        </ul>
                        <ul class="list-unstyled">
                            <li><strong>Veterinary Care:</strong></li>
                            <li>Annual check-ups</li>
                            <li>Vaccinations</li>
                            <li>Parasite prevention</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card care-card h-100 text-center border-0 shadow-lg rounded-4">
                    <div class="card-body py-5">
                        <i class="fas fa-home fa-3x text-success mb-3"></i>
                        <h5 class="card-title fw-bold mb-3">Environment</h5>
                        <ul class="list-unstyled mb-2">
                            <li><strong>Home Setup:</strong></li>
                            <li>Litter box maintenance</li>
                            <li>Scratching posts</li>
                            <li>Comfortable resting areas</li>
                            <li>Safe toys and play areas</li>
                        </ul>
                        <ul class="list-unstyled">
                            <li><strong>Safety Tips:</strong></li>
                            <li>Keep toxic plants away</li>
                            <li>Secure windows and balconies</li>
                            <li>Hide electrical cords</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4 mt-4">
            <div class="col-md-6">
                <div class="card care-card h-100 border-0 shadow-lg rounded-4">
                    <div class="card-body py-5">
                        <i class="fas fa-chalkboard-teacher fa-3x text-primary mb-3"></i>
                        <h5 class="card-title fw-bold mb-3">Behavior & Training</h5>
                        <ul class="list-unstyled mb-2">
                            <li><strong>Basic Training:</strong></li>
                            <li>Litter box training</li>
                            <li>Scratching post use</li>
                            <li>Basic commands</li>
                        </ul>
                        <ul class="list-unstyled">
                            <li><strong>Common Behaviors:</strong></li>
                            <li>Understanding body language</li>
                            <li>Play behavior</li>
                            <li>Socialization</li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card care-card h-100 border-0 shadow-lg rounded-4">
                    <div class="card-body py-5">
                        <i class="fas fa-ambulance fa-3x text-danger mb-3"></i>
                        <h5 class="card-title fw-bold mb-3">Emergency Care</h5>
                        <ul class="list-unstyled mb-2">
                            <li><strong>Emergency Signs:</strong></li>
                            <li>Difficulty breathing</li>
                            <li>Sudden behavior changes</li>
                            <li>Vomiting or diarrhea</li>
                            <li>Injury or bleeding</li>
                        </ul>
                        <ul class="list-unstyled">
                            <li><strong>Emergency Contacts:</strong></li>
                            <li>Veterinarian: (555) 123-4567</li>
                            <li>Emergency Clinic: (555) 987-6543</li>
                            <li>Poison Control: (555) 456-7890</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 