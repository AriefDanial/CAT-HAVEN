<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Fetch upcoming events from database
$sql = "SELECT * FROM events WHERE event_date >= CURDATE() ORDER BY event_date ASC";
$stmt = $pdo->query($sql);
$events = $stmt->fetchAll();
?>

<?php include 'includes/header.php'; ?>

<!-- Hero Banner -->
<div class="py-5 text-center" style="background: linear-gradient(135deg, #fbc2eb 0%, #a6c1ee 100%);">
    <div class="container">
        <h1 class="display-4 fw-bold mb-2">Upcoming Events</h1>
        <p class="lead mb-0">Join us for exciting cat-related events and activities!</p>
    </div>
</div>

<div class="container my-5">
    <div class="row g-4">
        <?php if (!empty($events)): ?>
            <?php foreach($events as $event): ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card h-100 border-0 shadow-sm rounded-4 event-card">
                        <?php if($event['image']): ?>
                            <img src="<?php echo htmlspecialchars($event['image']); ?>" class="card-img-top rounded-top-4" alt="<?php echo htmlspecialchars($event['title']); ?>">
                        <?php endif; ?>
                        <div class="card-body p-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="badge bg-primary rounded-pill">
                                    <?php echo date('M d, Y', strtotime($event['event_date'])); ?>
                                </span>
                                <span class="badge bg-secondary rounded-pill">
                                    <?php echo date('h:i A', strtotime($event['event_time'])); ?>
                                </span>
                            </div>
                            <h3 class="card-title h4 mb-3"><?php echo htmlspecialchars($event['title']); ?></h3>
                            <p class="card-text text-muted mb-3"><?php echo htmlspecialchars($event['description']); ?></p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="text-primary">
                                    <i class="fas fa-map-marker-alt me-2"></i>
                                    <?php echo htmlspecialchars($event['location']); ?>
                                </span>
                                <?php if($event['registration_required']): ?>
                                    <a href="register_event.php?id=<?php echo $event['id']; ?>" class="btn btn-primary rounded-pill px-4">
                                        Register Now
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center py-5">
                <i class="fas fa-calendar-alt fa-3x text-muted mb-3"></i>
                <h3>No Upcoming Events</h3>
                <p class="text-muted">Check back soon for new events!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.event-card {
    transition: transform 0.2s ease-in-out;
}

.event-card:hover {
    transform: translateY(-5px);
}

.event-card .card-img-top {
    height: 200px;
    object-fit: cover;
}

.badge {
    font-size: 0.9rem;
    padding: 0.5em 1em;
}
</style>

<?php include 'includes/footer.php'; ?> 