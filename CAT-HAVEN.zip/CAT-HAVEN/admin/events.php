<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is admin
if (!isAdmin()) {
    header('Location: ../login.php');
    exit();
}

$success_message = '';
$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
            case 'edit':
                $title = trim($_POST['title'] ?? '');
                $description = trim($_POST['description'] ?? '');
                $event_date = trim($_POST['event_date'] ?? '');
                $event_time = trim($_POST['event_time'] ?? '');
                $location = trim($_POST['location'] ?? '');
                $registration_required = isset($_POST['registration_required']) ? 1 : 0;
                
                // Handle image upload
                $image = '';
                if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
                    $upload_dir = '../uploads/events/';
                    if (!file_exists($upload_dir)) {
                        mkdir($upload_dir, 0777, true);
                    }
                    
                    $file_extension = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
                    $new_filename = uniqid() . '.' . $file_extension;
                    $upload_path = $upload_dir . $new_filename;
                    
                    if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
                        $image = 'uploads/events/' . $new_filename;
                    }
                }
                
                try {
                    if ($_POST['action'] === 'add') {
                        $sql = "INSERT INTO events (title, description, event_date, event_time, location, registration_required, image) 
                                VALUES (?, ?, ?, ?, ?, ?, ?)";
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute([$title, $description, $event_date, $event_time, $location, $registration_required, $image]);
                    } else {
                        $id = $_POST['event_id'];
                        $sql = "UPDATE events SET title=?, description=?, event_date=?, event_time=?, location=?, registration_required=?, image=COALESCE(?, image) WHERE id=?";
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute([$title, $description, $event_date, $event_time, $location, $registration_required, $image, $id]);
                    }
                    $success_message = 'Event ' . ($_POST['action'] === 'add' ? 'added' : 'updated') . ' successfully!';
                } catch (PDOException $e) {
                    $error_message = 'Error: ' . $e->getMessage();
                }
                break;
                
            case 'delete':
                try {
                    $id = $_POST['event_id'];
                    $sql = "DELETE FROM events WHERE id = ?";
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute([$id]);
                    $success_message = 'Event deleted successfully!';
                } catch (PDOException $e) {
                    $error_message = 'Error: ' . $e->getMessage();
                }
                break;
        }
    }
}

// Fetch all events
$sql = "SELECT * FROM events ORDER BY event_date DESC";
$stmt = $pdo->query($sql);
$events = $stmt->fetchAll();
?>

<?php include '../includes/admin_header.php'; ?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="h3 mb-0">Manage Events</h1>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addEventModal">
            <i class="fas fa-plus me-2"></i>Add New Event
        </button>
    </div>

    <?php if ($success_message): ?>
        <div class="alert alert-success"><?php echo $success_message; ?></div>
    <?php endif; ?>
    <?php if ($error_message): ?>
        <div class="alert alert-danger"><?php echo $error_message; ?></div>
    <?php endif; ?>

    <div class="card border-0 shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Date & Time</th>
                            <th>Location</th>
                            <th>Registration</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($events)): ?>
                            <?php foreach($events as $event): ?>
                                <tr>
                                    <td>
                                        <?php if($event['image']): ?>
                                            <img src="../<?php echo htmlspecialchars($event['image']); ?>" 
                                                 class="rounded me-2" 
                                                 style="width: 40px; height: 40px; object-fit: cover;">
                                        <?php endif; ?>
                                        <?php echo htmlspecialchars($event['title']); ?>
                                    </td>
                                    <td>
                                        <?php echo date('M d, Y', strtotime($event['event_date'])); ?>
                                        <br>
                                        <small class="text-muted">
                                            <?php echo date('h:i A', strtotime($event['event_time'])); ?>
                                        </small>
                                    </td>
                                    <td><?php echo htmlspecialchars($event['location']); ?></td>
                                    <td>
                                        <?php if($event['registration_required']): ?>
                                            <span class="badge bg-success">Required</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">Not Required</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-primary me-2"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#editEventModal<?php echo $event['id']; ?>">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-danger"
                                                data-bs-toggle="modal" 
                                                data-bs-target="#deleteEventModal<?php echo $event['id']; ?>">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center py-4">
                                    <i class="fas fa-calendar-alt fa-2x text-muted mb-3"></i>
                                    <p class="mb-0">No events found</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add Event Modal -->
<div class="modal fade" id="addEventModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Event</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Title *</label>
                            <input type="text" class="form-control" name="title" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Image</label>
                            <input type="file" class="form-control" name="image" accept="image/*">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Date *</label>
                            <input type="date" class="form-control" name="event_date" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Time *</label>
                            <input type="time" class="form-control" name="event_time" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Location *</label>
                            <input type="text" class="form-control" name="location" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Description *</label>
                            <textarea class="form-control" name="description" rows="4" required></textarea>
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" name="registration_required" id="registrationRequired">
                                <label class="form-check-label" for="registrationRequired">
                                    Registration Required
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Event</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Event Modals -->
<?php foreach($events as $event): ?>
<div class="modal fade" id="editEventModal<?php echo $event['id']; ?>" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Event</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Title *</label>
                            <input type="text" class="form-control" name="title" value="<?php echo htmlspecialchars($event['title']); ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Image</label>
                            <input type="file" class="form-control" name="image" accept="image/*">
                            <?php if($event['image']): ?>
                                <small class="text-muted">Current image: <?php echo basename($event['image']); ?></small>
                            <?php endif; ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Date *</label>
                            <input type="date" class="form-control" name="event_date" value="<?php echo $event['event_date']; ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Time *</label>
                            <input type="time" class="form-control" name="event_time" value="<?php echo $event['event_time']; ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Location *</label>
                            <input type="text" class="form-control" name="location" value="<?php echo htmlspecialchars($event['location']); ?>" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Description *</label>
                            <textarea class="form-control" name="description" rows="4" required><?php echo htmlspecialchars($event['description']); ?></textarea>
                        </div>
                        <div class="col-12">
                            <div class="form-check">
                                <input type="checkbox" class="form-check-input" name="registration_required" id="registrationRequired<?php echo $event['id']; ?>"
                                    <?php echo $event['registration_required'] ? 'checked' : ''; ?>>
                                <label class="form-check-label" for="registrationRequired<?php echo $event['id']; ?>">
                                    Registration Required
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Event</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Delete Event Modal -->
<div class="modal fade" id="deleteEventModal<?php echo $event['id']; ?>" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="event_id" value="<?php echo $event['id']; ?>">
                <div class="modal-header">
                    <h5 class="modal-title">Delete Event</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete the event "<?php echo htmlspecialchars($event['title']); ?>"?</p>
                    <p class="text-danger mb-0">This action cannot be undone.</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Delete Event</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; ?>

<?php include '../includes/admin_footer.php'; ?> 