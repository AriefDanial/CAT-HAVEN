<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Require admin authentication
requireAdmin();

$success_message = '';
$error_message = '';

// Handle cat deletion
if (isset($_POST['delete_cat']) && isset($_POST['cat_id'])) {
    $cat_id = $_POST['cat_id'];
    
    try {
        // Start transaction
        $pdo->beginTransaction();
        
        // First delete associated adoption applications
        $stmt = $pdo->prepare("DELETE FROM adoption_applications WHERE cat_id = ?");
        $stmt->execute([$cat_id]);
        
        // Then delete the cat's image if it exists
        $stmt = $pdo->prepare("SELECT image FROM cats WHERE id = ?");
        $stmt->execute([$cat_id]);
        $cat = $stmt->fetch();
        
        if ($cat && $cat['image']) {
            $image_path = '../assets/uploads/' . $cat['image'];
            if (file_exists($image_path)) {
                unlink($image_path);
            }
        }
        
        // Finally delete the cat record
        $stmt = $pdo->prepare("DELETE FROM cats WHERE id = ?");
        if ($stmt->execute([$cat_id])) {
            $pdo->commit();
            $success_message = "Cat and associated applications successfully deleted.";
        } else {
            throw new Exception("Error deleting cat.");
        }
    } catch (Exception $e) {
        $pdo->rollBack();
        $error_message = "Error: " . $e->getMessage();
    }
}

// Handle cat status update
if (isset($_POST['update_status']) && isset($_POST['cat_id']) && isset($_POST['status'])) {
    $cat_id = $_POST['cat_id'];
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE cats SET status = ? WHERE id = ?");
    if ($stmt->execute([$status, $cat_id])) {
        $success_message = "Cat status updated successfully.";
    } else {
        $error_message = "Error updating cat status.";
    }
}

// Fetch all cats
$stmt = $pdo->query("SELECT * FROM cats ORDER BY created_at DESC");
$cats = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Cats - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            font-family: 'Poppins', Arial, sans-serif;
        }
        .admin-header {
            background: linear-gradient(135deg, #4a90e2 0%, #6a5acd 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .cat-card {
            border: none;
            border-radius: 15px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        .cat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .cat-image {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
        }
        .status-available {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        .status-adopted {
            background: rgba(108, 117, 125, 0.1);
            color: #6c757d;
        }
        .status-pending {
            background: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        .btn-action {
            padding: 0.5rem 1rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .table {
            background: white;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .table thead th {
            background: #f8f9fa;
            border-bottom: none;
            padding: 1rem;
            font-weight: 600;
        }
        .table tbody td {
            padding: 1rem;
            vertical-align: middle;
        }
        .form-select {
            border-radius: 10px;
            padding: 0.5rem 1rem;
            border: 1px solid #dee2e6;
            transition: all 0.3s ease;
        }
        .form-select:focus {
            box-shadow: 0 0 0 0.2rem rgba(74, 144, 226, 0.25);
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="admin-header">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="display-4 mb-0">Manage Cats</h1>
                    <p class="lead mb-0">Total Cats: <?php echo count($cats); ?></p>
                </div>
                <a href="add_cat.php" class="btn btn-light btn-lg">
                    <i class="fas fa-plus"></i> Add New Cat
                </a>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if ($success_message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Image</th>
                        <th>Name</th>
                        <th>Breed</th>
                        <th>Age</th>
                        <th>Gender</th>
                        <th>Status</th>
                        <th>Added Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cats as $cat): ?>
                        <tr>
                            <td>
                                <?php
                                $image_path = '../assets/uploads/' . $cat['image'];
                                $default_image = '../assets/images/default-cat.jpg';
                                ?>
                                <img src="<?php echo file_exists($image_path) ? $image_path : $default_image; ?>" 
                                     alt="<?php echo htmlspecialchars($cat['name']); ?>"
                                     class="cat-image">
                            </td>
                            <td>
                                <h6 class="mb-0"><?php echo htmlspecialchars($cat['name']); ?></h6>
                            </td>
                            <td><?php echo htmlspecialchars($cat['breed']); ?></td>
                            <td><?php echo htmlspecialchars($cat['age']); ?> years</td>
                            <td><?php echo htmlspecialchars($cat['gender']); ?></td>
                            <td>
                                <form method="POST" class="d-inline">
                                    <input type="hidden" name="cat_id" value="<?php echo $cat['id']; ?>">
                                    <select name="status" class="form-select form-select-sm" 
                                            onchange="this.form.submit()"
                                            style="width: 120px;">
                                        <option value="available" <?php echo $cat['status'] === 'available' ? 'selected' : ''; ?>>Available</option>
                                        <option value="adopted" <?php echo $cat['status'] === 'adopted' ? 'selected' : ''; ?>>Adopted</option>
                                        <option value="pending" <?php echo $cat['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    </select>
                                    <input type="hidden" name="update_status" value="1">
                                </form>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($cat['created_at'])); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="edit_cat.php?id=<?php echo $cat['id']; ?>" 
                                       class="btn btn-info btn-action">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <form method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this cat?');">
                                        <input type="hidden" name="cat_id" value="<?php echo $cat['id']; ?>">
                                        <button type="submit" name="delete_cat" class="btn btn-danger btn-action">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 