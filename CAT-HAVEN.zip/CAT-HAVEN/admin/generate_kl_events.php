<?php
require_once '../includes/db_connect.php';

// Array of random KL events
$events = [
    [
        'KL Cat Carnival',
        'A fun-filled day for cat lovers with games, food, and cat adoptions.',
        '2024-07-20',
        '10:00:00',
        'Kuala Lumpur',
        1,
        ''
    ],
    [
        'Cat Health Talk',
        'Join us for a talk by a local vet on keeping your cat healthy.',
        '2024-08-05',
        '14:00:00',
        'Kuala Lumpur',
        0,
        ''
    ],
    [
        'KL Cat Show',
        'See the most beautiful cats in KL compete for prizes!',
        '2024-09-10',
        '09:00:00',
        'Kuala Lumpur',
        1,
        ''
    ],
    [
        'Adopt-a-Cat Day',
        'Meet adorable cats looking for a forever home.',
        '2024-07-28',
        '11:00:00',
        'Kuala Lumpur',
        1,
        ''
    ],
    [
        'Cat Care Workshop',
        'Learn the basics of cat care and nutrition.',
        '2024-08-15',
        '15:00:00',
        'Kuala Lumpur',
        0,
        ''
    ]
];

try {
    $stmt = $pdo->prepare("INSERT INTO events (title, description, event_date, event_time, location, registration_required, image) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $inserted = 0;
    foreach ($events as $event) {
        $stmt->execute($event);
        $inserted++;
    }
    echo "<h2>Successfully inserted $inserted KL events!</h2>";
} catch (PDOException $e) {
    echo "<h2>Error inserting events: " . htmlspecialchars($e->getMessage()) . "</h2>";
} 