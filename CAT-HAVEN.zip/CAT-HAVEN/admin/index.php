<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Require admin authentication
requireAdmin();

// Get counts for dashboard
$stmt = $pdo->query("SELECT COUNT(*) FROM cats");
$total_cats = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM cats WHERE status = 'available'");
$available_cats = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM cats WHERE status = 'adopted'");
$adopted_cats = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM adoption_applications");
$total_applications = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) FROM adoption_applications WHERE status = 'pending'");
$pending_applications = $stmt->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Cat Haven</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            font-family: 'Poppins', Arial, sans-serif;
        }
        .admin-header {
            background: linear-gradient(135deg, #4a90e2 0%, #6a5acd 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .stat-card {
            border: none;
            border-radius: 15px;
            transition: transform 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-card .card-body {
            padding: 1.5rem;
        }
        .stat-card .icon-circle {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
        }
        .stat-card .stat-number {
            font-size: 2rem;
            font-weight: bold;
            margin: 0.5rem 0;
        }
        .stat-card .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        .quick-actions {
            background: white;
            border-radius: 15px;
            padding: 1.5rem;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .quick-actions .btn {
            padding: 0.8rem 1.5rem;
            border-radius: 10px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .quick-actions .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none;
        }
        .btn-warning {
            background: linear-gradient(135deg, #ffc107 0%, #ff9800 100%);
            border: none;
        }
        .btn-info {
            background: linear-gradient(135deg, #17a2b8 0%, #0dcaf0 100%);
            border: none;
        }
        .btn-primary {
            background: linear-gradient(135deg, #4a90e2 0%, #6a5acd 100%);
            border: none;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="admin-header">
        <div class="container">
            <h1 class="display-4 mb-0">Admin Dashboard</h1>
            <p class="lead mb-0">Welcome back, <?php echo htmlspecialchars(getCurrentUsername()); ?>!</p>
        </div>
    </div>

    <div class="container">
        <div class="row g-4">
            <!-- Cats Statistics -->
            <div class="col-md-4">
                <div class="stat-card card bg-white">
                    <div class="card-body">
                        <div class="icon-circle" style="background: rgba(74, 144, 226, 0.1);">
                            <i class="fas fa-cat fa-2x text-primary"></i>
                        </div>
                        <div class="stat-number text-primary"><?php echo $total_cats; ?></div>
                        <div class="stat-label">Total Cats</div>
                        <div class="mt-3">
                            <small class="text-success">
                                <i class="fas fa-circle"></i> <?php echo $available_cats; ?> Available
                            </small>
                            <br>
                            <small class="text-info">
                                <i class="fas fa-circle"></i> <?php echo $adopted_cats; ?> Adopted
                            </small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Applications Statistics -->
            <div class="col-md-4">
                <div class="stat-card card bg-white">
                    <div class="card-body">
                        <div class="icon-circle" style="background: rgba(255, 193, 7, 0.1);">
                            <i class="fas fa-file-alt fa-2x text-warning"></i>
                        </div>
                        <div class="stat-number text-warning"><?php echo $total_applications; ?></div>
                        <div class="stat-label">Total Applications</div>
                        <div class="mt-3">
                            <small class="text-warning">
                                <i class="fas fa-clock"></i> <?php echo $pending_applications; ?> Pending
                            </small>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="col-md-4">
                <div class="stat-card card bg-white">
                    <div class="card-body">
                        <div class="icon-circle" style="background: rgba(40, 167, 69, 0.1);">
                            <i class="fas fa-chart-line fa-2x text-success"></i>
                        </div>
                        <div class="stat-number text-success">
                            <?php echo round(($adopted_cats / max($total_cats, 1)) * 100); ?>%
                        </div>
                        <div class="stat-label">Adoption Rate</div>
                        <div class="mt-3">
                            <small class="text-muted">
                                <i class="fas fa-info-circle"></i> Based on total cats
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions mt-4">
            <h4 class="mb-4">Quick Actions</h4>
            <div class="d-flex gap-3 flex-wrap">
                <a href="add_cat.php" class="btn btn-success">
                    <i class="fas fa-plus"></i> Add New Cat
                </a>
                <a href="manage_cats.php" class="btn btn-primary">
                    <i class="fas fa-paw"></i> Manage Cats
                </a>
                <a href="applications.php?status=pending" class="btn btn-warning">
                    <i class="fas fa-clock"></i> View Pending Applications
                </a>
                <a href="stray_reports.php" class="btn btn-info">
                    <i class="fas fa-exclamation-circle"></i> Stray Cat Reports
                </a>
                <a href="events.php" class="btn btn-primary">
                    <i class="fas fa-calendar-plus"></i> Add Event
                </a>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="card mt-4">
            <div class="card-body">
                <h4 class="card-title mb-4">Recent Activity</h4>
                <div class="list-group">
                    <?php
                    // Get recent applications
                    $stmt = $pdo->query("SELECT a.*, c.name as cat_name, u.username 
                                       FROM adoption_applications a 
                                       JOIN cats c ON a.cat_id = c.id 
                                       JOIN users u ON a.user_id = u.id 
                                       ORDER BY a.created_at DESC LIMIT 5");
                    $recent_applications = $stmt->fetchAll();

                    foreach ($recent_applications as $app): ?>
                        <div class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <h6 class="mb-1">New adoption application for <?php echo htmlspecialchars($app['cat_name']); ?></h6>
                                <small class="text-muted"><?php echo date('M d, Y', strtotime($app['created_at'])); ?></small>
                            </div>
                            <p class="mb-1">By <?php echo htmlspecialchars($app['username']); ?></p>
                            <small class="text-<?php echo $app['status'] === 'pending' ? 'warning' : 
                                                    ($app['status'] === 'approved' ? 'success' : 'danger'); ?>">
                                Status: <?php echo ucfirst($app['status']); ?>
                            </small>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 