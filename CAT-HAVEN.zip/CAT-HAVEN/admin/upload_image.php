<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Require admin authentication
requireAdmin();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['cat_id']) && isset($_FILES['cat_image'])) {
        $cat_id = $_POST['cat_id'];
        $file = $_FILES['cat_image'];
        
        // Validate file
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_size = 5 * 1024 * 1024; // 5MB
        
        if (!in_array($file['type'], $allowed_types)) {
            $error = 'Invalid file type. Please upload a JPG, PNG, or GIF image.';
        } elseif ($file['size'] > $max_size) {
            $error = 'File is too large. Maximum size is 5MB.';
        } else {
            // Create uploads directory if it doesn't exist
            $upload_dir = '../assets/uploads/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = uniqid('cat_') . '.' . $extension;
            $target_path = $upload_dir . $filename;
            
            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                // Update database with new image filename
                try {
                    $stmt = $pdo->prepare("UPDATE cats SET image = ? WHERE id = ?");
                    $stmt->execute([$filename, $cat_id]);
                    $message = 'Image uploaded successfully!';
                } catch (PDOException $e) {
                    $error = 'Database error: ' . $e->getMessage();
                    // Remove uploaded file if database update fails
                    unlink($target_path);
                }
            } else {
                $error = 'Failed to upload image. Please try again.';
            }
        }
    } else {
        $error = 'Please select a cat and an image to upload.';
    }
}

// Fetch all cats for the dropdown
$cats = $pdo->query("SELECT id, name FROM cats ORDER BY name")->fetchAll();
?>

<?php include '../includes/header.php'; ?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2 class="mb-0">Upload Cat Image</h2>
                </div>
                <div class="card-body">
                    <?php if ($message): ?>
                        <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
                    <?php endif; ?>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label for="cat_id" class="form-label">Select Cat</label>
                            <select class="form-select" id="cat_id" name="cat_id" required>
                                <option value="">Choose a cat...</option>
                                <?php foreach ($cats as $cat): ?>
                                    <option value="<?php echo $cat['id']; ?>">
                                        <?php echo htmlspecialchars($cat['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label for="cat_image" class="form-label">Cat Image</label>
                            <input type="file" class="form-control" id="cat_image" name="cat_image" accept="image/*" required>
                            <div class="form-text">Maximum file size: 5MB. Allowed formats: JPG, PNG, GIF</div>
                        </div>
                        
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Upload Image</button>
                            <a href="index.php" class="btn btn-secondary">Back to Admin Panel</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?> 