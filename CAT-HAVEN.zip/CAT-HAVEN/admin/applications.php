<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Require admin authentication
requireAdmin();

// Handle status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['application_id']) && isset($_POST['status'])) {
    $application_id = $_POST['application_id'];
    $status = $_POST['status'];
    
    try {
        $stmt = $pdo->prepare("UPDATE adoption_applications SET status = ? WHERE id = ?");
        $stmt->execute([$status, $application_id]);
        
        // If approved, update cat status to adopted
        if ($status === 'approved') {
            $stmt = $pdo->prepare("UPDATE cats SET status = 'adopted' WHERE id = (SELECT cat_id FROM adoption_applications WHERE id = ?)");
            $stmt->execute([$application_id]);
        }
        
        $success = "Application status updated successfully!";
    } catch(PDOException $e) {
        $error = "Error updating application: " . $e->getMessage();
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? '';

// Build the query
$query = "SELECT a.*, c.name as cat_name, c.breed, u.username 
          FROM adoption_applications a 
          JOIN cats c ON a.cat_id = c.id 
          JOIN users u ON a.user_id = u.id";
$params = [];

if ($status_filter) {
    $query .= " WHERE a.status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY a.created_at DESC";

// Fetch applications
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$applications = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adoption Applications - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="container mt-5">
        <div class="row mb-4">
            <div class="col-md-8">
                <h1>Adoption Applications</h1>
            </div>
            <div class="col-md-4">
                <form method="GET" class="d-flex">
                    <select name="status" class="form-select me-2" onchange="this.form.submit()">
                        <option value="">All Applications</option>
                        <option value="pending" <?php echo $status_filter === 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="approved" <?php echo $status_filter === 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="rejected" <?php echo $status_filter === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
                    </select>
                </form>
            </div>
        </div>

        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <?php if (empty($applications)): ?>
            <div class="alert alert-info">No applications found.</div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Cat</th>
                            <th>Applicant</th>
                            <th>Contact</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applications as $app): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($app['id']); ?></td>
                                <td>
                                    <?php echo htmlspecialchars($app['cat_name']); ?><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($app['breed']); ?></small>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($app['first_name'] . ' ' . $app['last_name']); ?><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($app['username']); ?></small>
                                </td>
                                <td>
                                    <?php echo htmlspecialchars($app['email']); ?><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($app['phone']); ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-<?php 
                                        echo $app['status'] === 'approved' ? 'success' : 
                                            ($app['status'] === 'rejected' ? 'danger' : 'warning'); 
                                    ?>">
                                        <?php echo ucfirst(htmlspecialchars($app['status'])); ?>
                                    </span>
                                </td>
                                <td><?php echo date('M d, Y', strtotime($app['created_at'])); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#viewModal<?php echo $app['id']; ?>">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                    <?php if ($app['status'] === 'pending'): ?>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                            <input type="hidden" name="status" value="approved">
                                            <button type="submit" class="btn btn-sm btn-success" onclick="return confirm('Are you sure you want to approve this application?')">
                                                <i class="fas fa-check"></i> Approve
                                            </button>
                                        </form>
                                        <form method="POST" class="d-inline">
                                            <input type="hidden" name="application_id" value="<?php echo $app['id']; ?>">
                                            <input type="hidden" name="status" value="rejected">
                                            <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to reject this application?')">
                                                <i class="fas fa-times"></i> Reject
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <!-- View Modal -->
                            <div class="modal fade" id="viewModal<?php echo $app['id']; ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Application Details</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h6>Applicant Information</h6>
                                                    <p>
                                                        <strong>Name:</strong> <?php echo htmlspecialchars($app['first_name'] . ' ' . $app['last_name']); ?><br>
                                                        <strong>Email:</strong> <?php echo htmlspecialchars($app['email']); ?><br>
                                                        <strong>Phone:</strong> <?php echo htmlspecialchars($app['phone']); ?><br>
                                                        <strong>Address:</strong> <?php echo htmlspecialchars($app['address']); ?><br>
                                                        <strong>Occupation:</strong> <?php echo htmlspecialchars($app['occupation']); ?>
                                                    </p>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6>Cat Information</h6>
                                                    <p>
                                                        <strong>Name:</strong> <?php echo htmlspecialchars($app['cat_name']); ?><br>
                                                        <strong>Breed:</strong> <?php echo htmlspecialchars($app['breed']); ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="row mt-3">
                                                <div class="col-12">
                                                    <h6>Experience with Pets</h6>
                                                    <p><?php echo nl2br(htmlspecialchars($app['experience'])); ?></p>
                                                </div>
                                            </div>
                                            <div class="row mt-3">
                                                <div class="col-12">
                                                    <h6>Reason for Adoption</h6>
                                                    <p><?php echo nl2br(htmlspecialchars($app['reason'])); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 