<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Require admin authentication
requireAdmin();

$success_message = '';
$error_message = '';

// Handle status updates
if (isset($_POST['update_status']) && isset($_POST['report_id']) && isset($_POST['status'])) {
    $report_id = $_POST['report_id'];
    $status = $_POST['status'];
    
    try {
        $pdo->beginTransaction();
        
        // Update report status
        $stmt = $pdo->prepare("UPDATE stray_cat_reports SET status = ? WHERE id = ?");
        if ($stmt->execute([$status, $report_id])) {
            // Get report details for notification
            $stmt = $pdo->prepare("SELECT user_id FROM stray_cat_reports WHERE id = ?");
            $stmt->execute([$report_id]);
            $report = $stmt->fetch();
            
            if ($report) {
                // Create notification
                $message = "Your stray cat report has been marked as " . ucfirst($status);
                $stmt = $pdo->prepare("INSERT INTO notifications (user_id, report_id, message) VALUES (?, ?, ?)");
                $stmt->execute([$report['user_id'], $report_id, $message]);
            }
            
            $pdo->commit();
            $success_message = "Report status updated successfully.";
        } else {
            $pdo->rollBack();
            $error_message = "Error updating report status.";
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error_message = "Database error: " . $e->getMessage();
    }
}

// Get filter parameters
$status_filter = $_GET['status'] ?? '';

// Build the query
$query = "SELECT r.*, u.username 
          FROM stray_cat_reports r 
          JOIN users u ON r.user_id = u.id";
$params = [];

if ($status_filter) {
    $query .= " WHERE r.status = ?";
    $params[] = $status_filter;
}

$query .= " ORDER BY r.created_at DESC";

// Fetch reports
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$reports = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stray Cat Reports - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body, html {
            font-family: 'Poppins', Arial, sans-serif;
        }
        .admin-header {
            background: linear-gradient(135deg, #4a90e2 0%, #6a5acd 100%);
            color: white;
            padding: 2rem 0;
            margin-bottom: 2rem;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .report-card {
            border: none;
            border-radius: 15px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        .report-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .report-image {
            width: 200px;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
        }
        .status-pending {
            background: rgba(255, 193, 7, 0.1);
            color: #ffc107;
        }
        .status-reviewed {
            background: rgba(23, 162, 184, 0.1);
            color: #17a2b8;
        }
        .status-rescued {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        .status-closed {
            background: rgba(108, 117, 125, 0.1);
            color: #6c757d;
        }
        .btn-action {
            padding: 0.5rem 1rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .btn-action:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>

    <div class="admin-header">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h1 class="display-4 mb-0">Stray Cat Reports</h1>
                    <p class="lead mb-0">Total Reports: <?php echo count($reports); ?></p>
                </div>
                <div class="btn-group">
                    <a href="?status=pending" class="btn btn-warning">
                        <i class="fas fa-clock"></i> Pending
                    </a>
                    <a href="?status=reviewed" class="btn btn-info">
                        <i class="fas fa-eye"></i> Reviewed
                    </a>
                    <a href="?status=rescued" class="btn btn-success">
                        <i class="fas fa-check"></i> Rescued
                    </a>
                    <a href="?status=closed" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Closed
                    </a>
                    <a href="?" class="btn btn-light">
                        <i class="fas fa-list"></i> All
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <?php if ($success_message): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $success_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        <?php if ($error_message): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $error_message; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="row">
            <?php foreach ($reports as $report): ?>
                <div class="col-md-6 mb-4">
                    <div class="report-card card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <?php if ($report['image']): ?>
                                        <img src="../assets/uploads/reports/<?php echo htmlspecialchars($report['image']); ?>" 
                                             alt="Stray cat report" 
                                             class="report-image mb-3">
                                    <?php else: ?>
                                        <div class="report-image mb-3 bg-light d-flex align-items-center justify-content-center">
                                            <i class="fas fa-cat fa-3x text-muted"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="col-md-8">
                                    <div class="d-flex justify-content-between align-items-start mb-3">
                                        <h5 class="card-title mb-0">Report #<?php echo $report['id']; ?></h5>
                                        <span class="status-badge status-<?php echo $report['status']; ?>">
                                            <?php echo ucfirst($report['status']); ?>
                                        </span>
                                    </div>
                                    <p class="card-text">
                                        <strong>Location:</strong> <?php echo htmlspecialchars($report['location']); ?><br>
                                        <strong>Reported by:</strong> <?php echo htmlspecialchars($report['username']); ?><br>
                                        <strong>Contact:</strong> <?php echo htmlspecialchars($report['contact_info']); ?><br>
                                        <strong>Date:</strong> <?php echo date('M d, Y', strtotime($report['created_at'])); ?>
                                    </p>
                                    <p class="card-text">
                                        <strong>Description:</strong><br>
                                        <?php echo nl2br(htmlspecialchars($report['description'])); ?>
                                    </p>
                                    <form method="POST" class="mt-3">
                                        <input type="hidden" name="report_id" value="<?php echo $report['id']; ?>">
                                        <div class="input-group">
                                            <select name="status" class="form-select">
                                                <option value="pending" <?php echo $report['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                                                <option value="reviewed" <?php echo $report['status'] === 'reviewed' ? 'selected' : ''; ?>>Reviewed</option>
                                                <option value="rescued" <?php echo $report['status'] === 'rescued' ? 'selected' : ''; ?>>Rescued</option>
                                                <option value="closed" <?php echo $report['status'] === 'closed' ? 'selected' : ''; ?>>Closed</option>
                                            </select>
                                            <button type="submit" name="update_status" class="btn btn-primary">
                                                <i class="fas fa-save"></i> Update Status
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <?php include '../includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 