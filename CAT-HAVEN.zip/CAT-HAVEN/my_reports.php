<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Require user authentication
requireLogin();

$user_id = getCurrentUserId();

// Get user's reports
$stmt = $pdo->prepare("
    SELECT r.*, 
           (SELECT COUNT(*) FROM notifications n WHERE n.report_id = r.id AND n.is_read = FALSE) as unread_notifications
    FROM stray_cat_reports r 
    WHERE r.user_id = ? 
    ORDER BY r.created_at DESC
");
$stmt->execute([$user_id]);
$reports = $stmt->fetchAll();

// Get all notifications for the user
$stmt = $pdo->prepare("
    SELECT n.*, r.location 
    FROM notifications n 
    JOIN stray_cat_reports r ON n.report_id = r.id 
    WHERE n.user_id = ? 
    ORDER BY n.created_at DESC
");
$stmt->execute([$user_id]);
$notifications = $stmt->fetchAll();

// Mark notifications as read if requested
if (isset($_POST['mark_read']) && isset($_POST['notification_id'])) {
    $stmt = $pdo->prepare("UPDATE notifications SET is_read = TRUE WHERE id = ? AND user_id = ?");
    $stmt->execute([$_POST['notification_id'], $user_id]);
    header('Location: my_reports.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Reports - Cat Haven</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .report-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .report-card:hover {
            transform: translateY(-5px);
        }
        .notification-item {
            border-left: 4px solid #4a90e2;
            background: #f8f9fa;
            margin-bottom: 1rem;
            padding: 1rem;
            border-radius: 0 10px 10px 0;
        }
        .notification-item.unread {
            background: #e3f2fd;
            border-left-color: #2196f3;
        }
        .status-badge {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-weight: 500;
        }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-reviewed { background: #cce5ff; color: #004085; }
        .status-rescued { background: #d4edda; color: #155724; }
        .status-closed { background: #f8f9fa; color: #6c757d; }
    </style>
</head>
<body>
    <?php include 'includes/header.php'; ?>

    <div class="container py-5">
        <h1 class="mb-4">My Stray Cat Reports</h1>

        <!-- Notifications Section -->
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <i class="fas fa-bell"></i> Notifications
                    <?php 
                    $unread_count = array_reduce($notifications, function($carry, $item) {
                        return $carry + (!$item['is_read'] ? 1 : 0);
                    }, 0);
                    if ($unread_count > 0): 
                    ?>
                        <span class="badge bg-danger"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </h5>
            </div>
            <div class="card-body">
                <?php if (empty($notifications)): ?>
                    <p class="text-muted">No notifications yet.</p>
                <?php else: ?>
                    <?php foreach ($notifications as $notification): ?>
                        <div class="notification-item <?php echo $notification['is_read'] ? '' : 'unread'; ?>">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <p class="mb-1"><?php echo htmlspecialchars($notification['message']); ?></p>
                                    <small class="text-muted">
                                        Location: <?php echo htmlspecialchars($notification['location']); ?> |
                                        <?php echo date('M d, Y H:i', strtotime($notification['created_at'])); ?>
                                    </small>
                                </div>
                                <?php if (!$notification['is_read']): ?>
                                    <form method="POST" class="ms-2">
                                        <input type="hidden" name="notification_id" value="<?php echo $notification['id']; ?>">
                                        <button type="submit" name="mark_read" class="btn btn-sm btn-outline-primary">
                                            Mark as Read
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <!-- Reports Section -->
        <div class="row">
            <?php if (empty($reports)): ?>
                <div class="col-12">
                    <div class="alert alert-info">
                        You haven't submitted any stray cat reports yet. 
                        <a href="report_cat.php" class="alert-link">Report a stray cat</a>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($reports as $report): ?>
                    <div class="col-md-6 mb-4">
                        <div class="report-card card">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start mb-3">
                                    <h5 class="card-title mb-0">Report #<?php echo $report['id']; ?></h5>
                                    <span class="status-badge status-<?php echo $report['status']; ?>">
                                        <?php echo ucfirst($report['status']); ?>
                                    </span>
                                </div>
                                
                                <?php if ($report['image']): ?>
                                    <img src="assets/uploads/reports/<?php echo htmlspecialchars($report['image']); ?>" 
                                         alt="Stray cat report" 
                                         class="img-fluid rounded mb-3"
                                         style="max-height: 200px; width: 100%; object-fit: cover;">
                                <?php endif; ?>

                                <p class="card-text">
                                    <strong>Location:</strong> <?php echo htmlspecialchars($report['location']); ?><br>
                                    <strong>Contact:</strong> <?php echo htmlspecialchars($report['contact_info']); ?><br>
                                    <strong>Date:</strong> <?php echo date('M d, Y', strtotime($report['created_at'])); ?>
                                </p>
                                
                                <p class="card-text">
                                    <strong>Description:</strong><br>
                                    <?php echo nl2br(htmlspecialchars($report['description'])); ?>
                                </p>

                                <?php if ($report['unread_notifications'] > 0): ?>
                                    <div class="alert alert-info">
                                        <i class="fas fa-bell"></i> 
                                        <?php echo $report['unread_notifications']; ?> new notification(s)
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 