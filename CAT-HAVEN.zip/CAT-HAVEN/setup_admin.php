<?php
require_once 'includes/config.php';

try {
    // Check if admin user exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = 'admin'");
    $stmt->execute();
    $admin = $stmt->fetch();

    if (!$admin) {
        // Create admin user
        $username = 'admin';
        $email = 'admin@cathaven.com';
        $password = password_hash('admin123', PASSWORD_DEFAULT);
        $role = 'admin';

        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $stmt->execute([$username, $email, $password, $role]);

        echo "Admin user created successfully!<br>";
        echo "Username: admin<br>";
        echo "Password: admin123<br>";
        echo "<strong>Please change these credentials after first login!</strong>";
    } else {
        echo "Admin user already exists.";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?> 