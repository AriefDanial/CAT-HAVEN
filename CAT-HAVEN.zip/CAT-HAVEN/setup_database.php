<?php
require_once 'includes/config.php';

try {
    // Create users table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('user', 'admin') DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Create cats table if it doesn't exist
    $pdo->exec("CREATE TABLE IF NOT EXISTS cats (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        age INT NOT NULL,
        breed VARCHAR(100) NOT NULL,
        gender ENUM('Male', 'Female') NOT NULL,
        description TEXT NOT NULL,
        image VARCHAR(255) DEFAULT NULL,
        status ENUM('available', 'adopted', 'pending') DEFAULT 'available',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Drop adoption_applications table if it exists
    $pdo->exec("DROP TABLE IF EXISTS adoption_applications");

    // Create adoption_applications table
    $pdo->exec("CREATE TABLE adoption_applications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cat_id INT NOT NULL,
        user_id INT NOT NULL,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        address TEXT NOT NULL,
        occupation VARCHAR(100) NOT NULL,
        experience TEXT NOT NULL,
        reason TEXT NOT NULL,
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (cat_id) REFERENCES cats(id),
        FOREIGN KEY (user_id) REFERENCES users(id)
    )");

    echo "<div style='background-color: #d4edda; color: #155724; padding: 15px; margin: 10px; border-radius: 5px;'>";
    echo "<h3>Database setup completed successfully!</h3>";
    echo "<p>The following tables have been created/verified:</p>";
    echo "<ul>";
    echo "<li>users</li>";
    echo "<li>cats</li>";
    echo "<li>adoption_applications</li>";
    echo "</ul>";
    echo "</div>";

    // Display the structure of adoption_applications table
    echo "<div style='background-color: #f8f9fa; padding: 15px; margin: 10px; border-radius: 5px;'>";
    echo "<h3>Adoption Applications Table Structure:</h3>";
    $stmt = $pdo->query("DESCRIBE adoption_applications");
    echo "<pre>";
    while ($row = $stmt->fetch()) {
        print_r($row);
    }
    echo "</pre>";
    echo "</div>";

} catch(PDOException $e) {
    echo "<div style='background-color: #f8d7da; color: #721c24; padding: 15px; margin: 10px; border-radius: 5px;'>";
    echo "<h3>Error setting up database:</h3>";
    echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "</div>";
}
?> 